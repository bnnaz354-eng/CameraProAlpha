# Camera Pro Alpha — สร้าง APK ด้วยมือถือ Android

แพ็กเกจนี้มีซอร์สโค้ดแอปและ GitHub Actions workflow สำหรับให้ GitHub สร้าง APK บนคลาวด์
**ยังไม่ใช่ไฟล์ APK ที่คอมไพล์แล้ว** ต้องอัปโหลดโปรเจกต์ขึ้น GitHub ก่อนจึงจะสั่ง Build ได้

## วิธีทำจากมือถืออย่างเดียว

1. ดาวน์โหลด ZIP นี้และแตกไฟล์ด้วยแอปจัดการไฟล์ในมือถือ
2. เข้า https://github.com/ แล้วสมัคร/เข้าสู่ระบบ
3. สร้าง repository ใหม่ ตั้งชื่อเช่น `CameraProAlpha` เลือก **Public** (ง่ายสุด) แล้วกด Create repository
4. อัปโหลดไฟล์และโฟลเดอร์ทั้งหมดที่อยู่ภายในโฟลเดอร์ `CameraProAndroid` ไปไว้ที่รากของ repository ให้เห็น `app`, `build.gradle.kts`, `settings.gradle.kts` และ `.github` ที่หน้าแรก
   - สำคัญ: ต้องอัปโหลดโฟลเดอร์ `.github/workflows` ด้วย หากแอป GitHub ซ่อนโฟลเดอร์ที่ขึ้นต้นด้วยจุด ให้ใช้เว็บ GitHub ใน Chrome และเลือก “Desktop site”
5. ไปที่แท็บ **Actions** ของ repository แล้วเปิดใช้งาน Actions หาก GitHub ถาม
6. Workflow จะเริ่มเมื่อ push ไฟล์ขึ้น `main`; หรือเลือก **Build Camera Pro APK** > **Run workflow** > **Run workflow**
7. รอจนงานขึ้นเครื่องหมายถูกสีเขียว แล้วเปิดงานนั้น เลื่อนลงหัวข้อ **Artifacts** แล้วแตะ `CameraPro-debug-APK` เพื่อดาวน์โหลด ZIP
8. แตก ZIP ที่ดาวน์โหลด จะพบ `app-debug.apk` แตะไฟล์เพื่อติดตั้ง และอนุญาต “ติดตั้งแอปที่ไม่รู้จัก” หาก Android ถาม

## หมายเหตุ
- APK นี้เป็น debug build สำหรับทดสอบ ไม่ใช่ไฟล์เผยแพร่บน Play Store
- ต้องใช้อินเทอร์เน็ต และ GitHub อาจให้ยืนยันบัญชีหรือเปิดใช้งาน Actions ก่อน
- ฟีเจอร์กล้องขึ้นกับฮาร์ดแวร์/เวอร์ชัน Android; AF-C เป็นเพียงต้นแบบ tap/focus metering ไม่ใช่ Sony Eye AF หรือ real-time subject tracking
