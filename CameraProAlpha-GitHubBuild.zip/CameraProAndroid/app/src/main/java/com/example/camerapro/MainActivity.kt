package com.example.camerapro

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.MeteringPointFactory
import android.view.MotionEvent
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var captureButton: Button
    private lateinit var flashButton: Button
    private lateinit var switchButton: Button
    private lateinit var exposureBar: SeekBar
    private lateinit var cameraExecutor: ExecutorService
    private var imageCapture: ImageCapture? = null
    private var camera: Camera? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var flashEnabled = false

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else toast("ต้องอนุญาตให้ใช้กล้องก่อน")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5, 7, 10)
        window.navigationBarColor = Color.rgb(5, 7, 10)
        cameraExecutor = Executors.newSingleThreadExecutor()
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(5, 7, 10))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 12, 18, 12)
        }
        header.addView(label("CAMERA PRO", 20f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("● PRO", 13f, Color.rgb(39, 165, 255), true))
        root.addView(header)

        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        root.addView(previewView, LinearLayout.LayoutParams(-1, 0, 1f))
        // Tap-to-focus: Sony Alpha-inspired touch autofocus behavior.
        previewView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                val activeCamera = camera
                if (activeCamera != null) {
                    val point = previewView.meteringPointFactory.createPoint(event.x, event.y)
                    val action = FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF)
                        .setAutoCancelDuration(3, java.util.concurrent.TimeUnit.SECONDS)
                        .build()
                    activeCamera.cameraControl.startFocusAndMetering(action)
                    toast("กำลังโฟกัส…")
                }
                true
            } else true
        }

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(8, 12, 8, 12)
        }
        listOf("ISO  Auto", "S  Auto", "EV  0.0", "AF  Auto").forEach {
            info.addView(label(it, 13f, Color.LTGRAY, false), LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(info)

        val focusModes = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(12, 0, 12, 4)
        }
        val afsButton = controlButton("AF-S • แตะโฟกัส") {
            toast("AF-S: แตะบนภาพเพื่อโฟกัสจุดนั้น")
        }
        val afcButton = controlButton("AF-C • ต่อเนื่อง") {
            val c = camera
            if (c != null) {
                try {
                    val point = previewView.meteringPointFactory.createPoint(
                        previewView.width / 2f, previewView.height / 2f
                    )
                    c.cameraControl.startFocusAndMetering(
                        FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF)
                            .disableAutoCancel().build()
                    )
                    toast("AF-C: พยายามติดตามโฟกัสต่อเนื่องที่กลางภาพ")
                } catch (_: Exception) {
                    toast("อุปกรณ์นี้ไม่รองรับการโฟกัสต่อเนื่องแบบที่ร้องขอ")
                }
            }
        }
        focusModes.addView(afsButton, LinearLayout.LayoutParams(0, 48, 1f))
        focusModes.addView(afcButton, LinearLayout.LayoutParams(0, 48, 1f))
        root.addView(focusModes)

        val expTitle = label("ชดเชยแสง (EV)", 13f, Color.LTGRAY, false).apply { setPadding(18, 2, 18, 0) }
        root.addView(expTitle)
        exposureBar = SeekBar(this).apply { max = 12; progress = 6; setPadding(18, 0, 18, 0) }
        exposureBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val c = camera ?: return
                val range = c.cameraInfo.exposureState.exposureCompensationRange
                val step = range.upper / 6.0
                val value = ((progress - 6) * step).toInt().coerceIn(range.lower, range.upper)
                c.cameraControl.setExposureCompensationIndex(value)
                expTitle.text = "ชดเชยแสง (EV)   ${String.format(Locale.US, "%+.1f", value * c.cameraInfo.exposureState.exposureCompensationStep.toFloat())}"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        root.addView(exposureBar)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(12, 12, 12, 24)
        }
        flashButton = controlButton("⚡ แฟลช") { flashEnabled = !flashEnabled; updateFlashLabel(); imageCapture?.flashMode = if (flashEnabled) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF }
        switchButton = controlButton("↻ สลับกล้อง") { lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK; startCamera() }
        val galleryButton = controlButton("▧ รูปภาพ") { openGallery() }
        captureButton = Button(this).apply {
            text = "●"; textSize = 30f; setTextColor(Color.WHITE)
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(39, 165, 255))
            contentDescription = "ถ่ายภาพ"
            setOnClickListener { takePhoto() }
        }
        controls.addView(flashButton, LinearLayout.LayoutParams(0, 54, 1f))
        controls.addView(captureButton, LinearLayout.LayoutParams(76, 68))
        controls.addView(switchButton, LinearLayout.LayoutParams(0, 54, 1f))
        root.addView(controls)
        root.addView(galleryButton, LinearLayout.LayoutParams(-1, 48))
        setContentView(root)
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun controlButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 11f; isAllCaps = false
        setTextColor(Color.WHITE)
        backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(28, 34, 42))
        setOnClickListener { action() }
    }

    private fun updateFlashLabel() { flashButton.text = if (flashEnabled) "⚡ แฟลชเปิด" else "⚡ แฟลชปิด" }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
            try {
                provider.unbindAll()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                imageCapture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build().also {
                    it.flashMode = if (flashEnabled) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
                }
                camera = provider.bindToLifecycle(this, selector, preview, imageCapture)
                exposureBar.progress = 6
            } catch (e: Exception) { toast("เปิดกล้องไม่สำเร็จ: ${e.localizedMessage ?: "ลองอีกครั้ง"}") }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val capture = imageCapture ?: run { toast("กล้องยังไม่พร้อม"); return }
        val name = "CameraPro_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/CameraPro")
        }
        val options = ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values).build()
        capture.takePicture(options, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) { toast("บันทึกรูปแล้วใน Pictures/CameraPro") }
            override fun onError(exception: ImageCaptureException) { toast("ถ่ายภาพไม่สำเร็จ: ${exception.localizedMessage}") }
        })
    }

    private fun openGallery() {
        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
            setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*")
            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { startActivity(intent) } catch (_: Exception) { toast("ไม่พบแอปแกลเลอรี") }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    override fun onDestroy() { super.onDestroy(); cameraExecutor.shutdown() }
}
